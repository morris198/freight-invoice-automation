"""
pipeline.py
-----------
Ties the four steps together and gives you a command-line tool:

    python pipeline.py sample_data/invoice_clean.txt
    python pipeline.py sample_data/*.txt --real     # use the real LLM
    python pipeline.py --report                      # show the ops queries

The orchestration is deliberately boring and readable: extract -> structure ->
validate -> store -> log. Each step is a function you can test on its own. Being
able to say "every stage is independently testable and the money decision is
made by auditable rules, not the model" is exactly what they want to hear.
"""

import argparse
import logging
import sys

import extraction
import llm_extract
import validation
import storage

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-7s  %(message)s",
    datefmt="%H:%M:%S",
)
log = logging.getLogger("pipeline")


def process_document(file_path: str, conn, use_mock: bool = True) -> dict:
    """Run one document through the full pipeline. Returns a result summary."""
    log.info("Processing %s", file_path)

    # 1. Ingest
    raw_text = extraction.extract_text(file_path)
    log.info("  Extracted %d chars of text", len(raw_text))

    # 2. Structure (LLM or mock)
    fields = llm_extract.extract_fields(raw_text, use_mock=use_mock)
    log.info("  Parsed invoice %s from %s",
             fields.get("invoice_number"), fields.get("vendor_name"))

    # 3. Validate / decide
    known = storage.known_invoice_numbers(conn)
    status, reasons = validation.validate(fields, known)

    # 4. Store
    doc_id = storage.save(conn, file_path, fields, status, reasons)

    if status == "AUTO_APPROVED":
        log.info("  -> AUTO_APPROVED (doc id %d)", doc_id)
    else:
        log.warning("  -> NEEDS_REVIEW (doc id %d): %s", doc_id, "; ".join(reasons))

    return {"id": doc_id, "status": status, "reasons": reasons, "fields": fields}


def print_report(conn):
    print("\n=== REVIEW QUEUE (human action needed) ===")
    for r in conn.execute(storage.REVIEW_QUEUE):
        print(f"  {r['invoice_number'] or '(no number)':<12} "
              f"{(r['vendor_name'] or '(no vendor)'):<22} "
              f"${r['total'] or 0:>10,.2f}   {r['review_reasons']}")

    print("\n=== AUTO-APPROVED PAYABLES ===")
    row = conn.execute(storage.PAYABLE_TOTAL).fetchone()
    print(f"  {row['invoices']} invoices, ${row['amount_payable'] or 0:,.2f} payable")

    print("\n=== EXCEPTION RATE BY VENDOR ===")
    for r in conn.execute(storage.EXCEPTION_RATE_BY_VENDOR):
        print(f"  {(r['vendor_name'] or '(unknown)'):<22} "
              f"{r['flagged']}/{r['total_docs']} flagged ({r['flagged_pct']}%)")
    print()


def main(argv=None):
    parser = argparse.ArgumentParser(description="Freight document automation")
    parser.add_argument("files", nargs="*", help="document files to process")
    parser.add_argument("--real", action="store_true",
                        help="use the Anthropic API instead of mock extraction")
    parser.add_argument("--report", action="store_true",
                        help="print the ops report and exit")
    parser.add_argument("--db", default="freight.db", help="SQLite path")
    args = parser.parse_args(argv)

    conn = storage.connect(args.db)

    for f in args.files:
        try:
            process_document(f, conn, use_mock=not args.real)
        except Exception as e:
            # One bad document should never kill the batch — log and move on.
            log.error("  FAILED on %s: %s", f, e)

    if args.report or not args.files:
        print_report(conn)

    conn.close()


if __name__ == "__main__":
    main()
