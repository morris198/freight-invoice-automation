"""
llm_extract.py
--------------
Step 2 of the pipeline: turn messy document text into clean, structured JSON.

This is the "AI-assisted decision" part. We give the model the raw text and a
strict schema, and ask it to return ONLY JSON. That's the "structured output"
pattern every production LLM workflow relies on: you don't want prose back, you
want data your code can act on.

Two modes:
  - REAL: calls the Anthropic API (set ANTHROPIC_API_KEY).
  - MOCK: a deterministic parser so the whole pipeline runs with no API key,
          no cost, and no network. Great for tests and demos.

Swapping mock for real is a one-line change in the pipeline, which is itself a
good design habit to be able to talk about: the pipeline doesn't care *how* the
fields get extracted, only that it gets the agreed-upon schema back.
"""

import json
import os
import re

# The schema we expect back. Documenting it here keeps the prompt and the
# validation/storage layers in agreement.
EXPECTED_FIELDS = [
    "doc_type", "invoice_number", "vendor_name", "invoice_date",
    "due_date", "subtotal", "tax", "total", "currency", "line_items",
]

SYSTEM_PROMPT = """You extract structured data from freight and accounting documents.
Return ONLY a JSON object. No markdown, no explanation, no code fences.

Use exactly these keys:
  doc_type       string   e.g. "invoice", "rate_confirmation"
  invoice_number string   the invoice or load/reference number
  vendor_name    string   who is billing us
  invoice_date   string   ISO format YYYY-MM-DD
  due_date       string   ISO format YYYY-MM-DD, or null
  subtotal       number
  tax            number
  total          number
  currency       string   3-letter code, default "USD"
  line_items     array    of {description, quantity, unit_price, amount}

If a field is missing from the document, use null. Never invent values."""


def extract_fields(raw_text: str, use_mock: bool = True) -> dict:
    """Return a dict of structured fields extracted from the document text."""
    if use_mock:
        return _mock_extract(raw_text)
    return _anthropic_extract(raw_text)


def _anthropic_extract(raw_text: str) -> dict:
    """Real extraction via the Anthropic API."""
    import anthropic  # lazy import so mock mode needs no dependency

    client = anthropic.Anthropic(api_key=os.environ["ANTHROPIC_API_KEY"])
    message = client.messages.create(
        model="claude-sonnet-4-6",
        max_tokens=1024,
        system=SYSTEM_PROMPT,
        messages=[{
            "role": "user",
            "content": f"Extract the fields from this document:\n\n{raw_text}",
        }],
    )
    text = message.content[0].text.strip()
    # Be defensive: strip any stray code fences before parsing.
    text = re.sub(r"^```(?:json)?|```$", "", text, flags=re.MULTILINE).strip()
    return json.loads(text)


def _mock_extract(raw_text: str) -> dict:
    """A tiny regex 'model' so the pipeline runs end-to-end offline.
    In the real project this is replaced by the LLM call above."""
    def find(pattern, cast=str, default=None):
        m = re.search(pattern, raw_text, re.IGNORECASE)
        if not m:
            return default
        try:
            return cast(m.group(1).strip().replace(",", ""))
        except (ValueError, AttributeError):
            return default

    line_items = []
    # Grab lines shaped like: description .... qty .. price .. amount
    for m in re.finditer(
        r"(?P<desc>[A-Za-z][\w /\-]+?)\s{2,}(?P<qty>\d+)\s+"
        r"(?P<price>[\d,]+\.\d{2})\s+(?P<amt>[\d,]+\.\d{2})",
        raw_text,
    ):
        line_items.append({
            "description": m.group("desc").strip(),
            "quantity": float(m.group("qty")),
            "unit_price": float(m.group("price").replace(",", "")),
            "amount": float(m.group("amt").replace(",", "")),
        })

    return {
        "doc_type": "invoice",
        "invoice_number": find(r"Invoice\s*#?\s*:?\s*([A-Z0-9\-]+)"),
        "vendor_name": find(r"(?:From|Vendor|Bill From)\s*:?\s*(.+)"),
        "invoice_date": find(r"(?:Invoice )?Date\s*:?\s*(\d{4}-\d{2}-\d{2})"),
        "due_date": find(r"Due\s*Date\s*:?\s*(\d{4}-\d{2}-\d{2})"),
        "subtotal": find(r"Subtotal\s*:?\s*\$?([\d,]+\.\d{2})", float),
        "tax": find(r"Tax\s*:?\s*\$?([\d,]+\.\d{2})", float, default=0.0),
        # Negative lookbehind so "Total" doesn't match inside "Subtotal".
        "total": find(r"(?<![A-Za-z])Total\s*:?\s*\$?([\d,]+\.\d{2})", float),
        "currency": "USD",
        "line_items": line_items,
    }
