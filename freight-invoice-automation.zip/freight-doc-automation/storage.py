"""
storage.py
----------
Step 4 of the pipeline: persist results to a SQL database (SQLite here, but the
SQL is standard enough to move to Postgres with almost no change).

This is your SQL story for the resume/interview. Two normalised tables with a
foreign-key relationship, plus a few analytical queries ops would actually run.
"""

import json
import sqlite3
from datetime import datetime

SCHEMA = """
CREATE TABLE IF NOT EXISTS documents (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    source_file    TEXT    NOT NULL,
    doc_type       TEXT,
    invoice_number TEXT,
    vendor_name    TEXT,
    invoice_date   TEXT,
    due_date       TEXT,
    subtotal       REAL,
    tax            REAL,
    total          REAL,
    currency       TEXT,
    status         TEXT    NOT NULL,          -- AUTO_APPROVED | NEEDS_REVIEW
    review_reasons TEXT,                      -- JSON array of strings
    raw_extraction TEXT,                      -- full JSON from the extractor
    processed_at   TEXT    NOT NULL
);

CREATE TABLE IF NOT EXISTS line_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    document_id INTEGER NOT NULL,
    description TEXT,
    quantity    REAL,
    unit_price  REAL,
    amount      REAL,
    FOREIGN KEY (document_id) REFERENCES documents(id)
);
"""


def connect(db_path: str = "freight.db") -> sqlite3.Connection:
    conn = sqlite3.connect(db_path)
    conn.row_factory = sqlite3.Row
    conn.executescript(SCHEMA)
    return conn


def known_invoice_numbers(conn: sqlite3.Connection) -> set[str]:
    """Used by the duplicate-detection rule."""
    rows = conn.execute(
        "SELECT invoice_number FROM documents WHERE invoice_number IS NOT NULL"
    ).fetchall()
    return {r["invoice_number"] for r in rows}


def save(conn, source_file, fields, status, reasons) -> int:
    """Insert one processed document and its line items. Returns the new id."""
    cur = conn.execute(
        """INSERT INTO documents
           (source_file, doc_type, invoice_number, vendor_name, invoice_date,
            due_date, subtotal, tax, total, currency, status, review_reasons,
            raw_extraction, processed_at)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
        (
            source_file,
            fields.get("doc_type"),
            fields.get("invoice_number"),
            fields.get("vendor_name"),
            fields.get("invoice_date"),
            fields.get("due_date"),
            fields.get("subtotal"),
            fields.get("tax"),
            fields.get("total"),
            fields.get("currency"),
            status,
            json.dumps(reasons),
            json.dumps(fields),
            datetime.now().isoformat(timespec="seconds"),
        ),
    )
    doc_id = cur.lastrowid

    for li in fields.get("line_items") or []:
        conn.execute(
            """INSERT INTO line_items
               (document_id, description, quantity, unit_price, amount)
               VALUES (?,?,?,?,?)""",
            (doc_id, li.get("description"), li.get("quantity"),
             li.get("unit_price"), li.get("amount")),
        )

    conn.commit()
    return doc_id


# --- Analytical queries: the kind of thing a manager asks for -----------------

REVIEW_QUEUE = """
SELECT invoice_number, vendor_name, total, review_reasons
FROM documents
WHERE status = 'NEEDS_REVIEW'
ORDER BY total DESC;
"""

PAYABLE_TOTAL = """
SELECT COUNT(*) AS invoices, ROUND(SUM(total), 2) AS amount_payable
FROM documents
WHERE status = 'AUTO_APPROVED';
"""

EXCEPTION_RATE_BY_VENDOR = """
SELECT vendor_name,
       COUNT(*) AS total_docs,
       SUM(CASE WHEN status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END) AS flagged,
       ROUND(100.0 * SUM(CASE WHEN status = 'NEEDS_REVIEW' THEN 1 ELSE 0 END)
             / COUNT(*), 1) AS flagged_pct
FROM documents
GROUP BY vendor_name
ORDER BY flagged_pct DESC;
"""
