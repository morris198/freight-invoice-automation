"""
validation.py
-------------
Step 3 of the pipeline: decide whether a document can be auto-approved or must
go to a human. This is the part that makes it *business* automation rather than
just "an LLM that reads PDFs."

The golden rule of automating money: the LLM extracts, but deterministic code
decides. You never let a language model be the final authority on whether to pay
an invoice. Rules you can read, test, and audit make that call.

Each rule returns a reason string if it fails, or None if it passes.
Any failed rule routes the document to NEEDS_REVIEW.
"""

from datetime import date, datetime

# Business policy knobs — the kind of thing you'd pull from config, not hardcode,
# in a real deployment. Easy to point at in an interview as "these are decisions
# the business owns, not the engineer."
AUTO_APPROVE_CEILING = 10_000.00   # anything above this always gets human eyes
MATH_TOLERANCE = 0.02              # allow 2 cents of rounding slop
REQUIRED_FIELDS = ["invoice_number", "vendor_name", "total"]


def validate(fields: dict, known_invoice_numbers: set[str]) -> tuple[str, list[str]]:
    """Run all rules. Return (status, reasons).
    status is 'AUTO_APPROVED' or 'NEEDS_REVIEW'."""
    reasons = []

    for check in (
        _required_fields,
        _total_is_positive,
        _line_items_sum_to_total,
        _date_is_sane,
        _under_approval_ceiling,
    ):
        result = check(fields)
        if result:
            reasons.append(result)

    # Duplicate check needs outside context (what we've already seen), so it's
    # handled separately rather than as a pure function of `fields`.
    dup = _not_a_duplicate(fields, known_invoice_numbers)
    if dup:
        reasons.append(dup)

    status = "NEEDS_REVIEW" if reasons else "AUTO_APPROVED"
    return status, reasons


def _required_fields(f: dict):
    missing = [name for name in REQUIRED_FIELDS if not f.get(name)]
    if missing:
        return f"Missing required field(s): {', '.join(missing)}"


def _total_is_positive(f: dict):
    total = f.get("total")
    if total is None:
        return None  # already caught by required-fields
    if total <= 0:
        return f"Total is not positive: {total}"


def _line_items_sum_to_total(f: dict):
    items = f.get("line_items") or []
    total = f.get("total")
    tax = f.get("tax") or 0.0
    if not items or total is None:
        return None
    line_sum = sum(li.get("amount", 0) or 0 for li in items)
    expected = round(line_sum + tax, 2)
    if abs(expected - total) > MATH_TOLERANCE:
        return (f"Line items + tax ({expected:.2f}) "
                f"do not match stated total ({total:.2f})")


def _date_is_sane(f: dict):
    raw = f.get("invoice_date")
    if not raw:
        return "Invoice date is missing"
    try:
        d = datetime.strptime(raw, "%Y-%m-%d").date()
    except ValueError:
        return f"Invoice date is not valid ISO format: {raw!r}"
    if d > date.today():
        return f"Invoice date is in the future: {raw}"


def _under_approval_ceiling(f: dict):
    total = f.get("total")
    if total is not None and total > AUTO_APPROVE_CEILING:
        return (f"Total {total:.2f} exceeds auto-approve ceiling "
                f"{AUTO_APPROVE_CEILING:.2f}")


def _not_a_duplicate(f: dict, known: set[str]):
    num = f.get("invoice_number")
    if num and num in known:
        return f"Duplicate invoice number already processed: {num}"
