"""
extraction.py
-------------
Step 1 of the pipeline: turn a document file into raw text.

Handles three cases so it works on real-world freight paperwork:
  - A text-based PDF (most invoices emailed from accounting software)
  - A scanned PDF or image (a driver's phone photo of a BOL) -> OCR
  - A plain .txt file (useful for testing without any PDF tooling)

The heavy libraries (pdfplumber, pytesseract) are imported lazily so the
rest of the pipeline runs even if you haven't installed them yet.
"""

from pathlib import Path


def extract_text(file_path: str) -> str:
    """Return the plain text contents of a document, whatever its format."""
    path = Path(file_path)
    suffix = path.suffix.lower()

    if suffix == ".txt":
        return path.read_text(encoding="utf-8")

    if suffix == ".pdf":
        return _extract_pdf(path)

    if suffix in {".png", ".jpg", ".jpeg", ".tiff"}:
        return _ocr_image(path)

    raise ValueError(f"Unsupported file type: {suffix}")


def _extract_pdf(path: Path) -> str:
    """Pull text from a PDF. Falls back to OCR if the page has no text layer
    (i.e. it's a scan)."""
    import pdfplumber  # lazy import

    text_parts = []
    with pdfplumber.open(path) as pdf:
        for page in pdf.pages:
            page_text = page.extract_text() or ""
            if page_text.strip():
                text_parts.append(page_text)
            else:
                # No text layer on this page -> it's a scan, OCR it.
                text_parts.append(_ocr_pdf_page(page))

    return "\n".join(text_parts)


def _ocr_pdf_page(page) -> str:
    """OCR a single pdfplumber page by rasterising it first."""
    import pytesseract  # lazy import

    image = page.to_image(resolution=200).original
    return pytesseract.image_to_string(image)


def _ocr_image(path: Path) -> str:
    """OCR a standalone image file (e.g. a photo of a paper BOL)."""
    import pytesseract
    from PIL import Image

    return pytesseract.image_to_string(Image.open(path))
